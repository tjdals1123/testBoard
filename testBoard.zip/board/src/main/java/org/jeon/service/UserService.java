package org.jeon.service;

import org.jeon.domain.UserVO;

public interface UserService {

	
	public UserVO getUser(UserVO userVO);
}
