package org.ict.domain;

import lombok.Data;

@Data
public class UserVO {

	private String uid;
	private String upw;
	private String uname;
	private String upoint;
	
}
